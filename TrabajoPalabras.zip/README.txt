Se inicia Servidor.java para iniciar el servidor y que se puedan conectar los usuarios
Se inicia IUPrincipal.java para iniciar la conexión de un usuario, los usuarios estan en RegistroDeJugadores.txt
Una vez iniciado IUPrincipal.java, nos pide un nick de usuario y una contraseña, en el caso de que
no tengamos un usuario creado, si ponemos el usuario que deseamos y la contraseña que deseamos se crea el usuario, en el caso de que
si tengamos un usuario creado, si ponemos el usuario bien pero la contraseña mal salta un mensaje de "Contraseña Incorrecta", si por
el contrario ponemos el usuario bien y la contraseña bien entramos al menu donde tenemos un ranking con el top3 de jugadores con mas puntos,
tambien estan los temas de los que se pueden crear mesas, un chat, y nos dice cuantos usuarios hay conectados.
Para crear una mesa clickamos en el tema que deseemos y se da a crear mesa, se crea la mesa con las palabras acordadas en RegistroDeTemas.txt
Una vez creada la mesa, el que ha creado la mesa puede elegir cuando empezar la partida, si bien esperar a que se unan jugadores o empezarla el solo.
Aquellos usuarios que quieran unirse a una mesa, tendrán que ver en que temas hay mesas creadas, unirse si lo desean o crear una nueva mesa, en el caso
de que se una a la mesa creada por otro jugador, tendrá que esperar a que el otro jugador empiece la partida.
Una vez dentro de la partida tendrán que acertar las palabras dentro del tiempo establecido, y tendrán que esperar a que el tiempo acabe
para poder pasar a la siguiente ronda, a la cual accederán una vez el creador de la partida pulse el botón "Comenzar", que comenzará la siguiente ronda
o bien se acabará la partida si ya no hay más palabras y por lo tanto no hay más rondas.
Tras acabar la partida en el chat se mostrará el resultado de la partida, con el tema que era, la mesa, y los puntos que se suman a cada jugador de
la mesa finalizada. Los puntos se sumarán al ranking y se seguirá viendo el ranking del top3. 
En el caso de que un jugador se loguee al servidor saldrá que se ha conectado en el chat, y si se desconecta saldrá que se ha desconectado