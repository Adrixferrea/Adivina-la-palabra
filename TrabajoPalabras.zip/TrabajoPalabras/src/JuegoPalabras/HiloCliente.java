package JuegoPalabras;

import java.io.DataInputStream;
import java.io.ObjectInputStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;

/**
 * Clase que se encarga de gestionar el hilo del cliente con ayuda de Thread
 */
public class HiloCliente extends Thread{
    
    private Socket scliente;
    private DataInputStream is;
    private IUPrincipal cliente;
    private IUMesa mesa;
    private ObjectInputStream iis;
    private boolean ejecutar=true;
    private Protocolo protocol;
    
    public HiloCliente(Socket SocketCliente, IUPrincipal cliente){
        this.scliente=SocketCliente;
        this.cliente=cliente;
    }
    
    /** Método que establece el nombre de la mesa
    @param mesa nombre de la mesa
   */
    public void setMesa(IUMesa mesa){
        this.mesa = mesa;
    }
    
    /** Método que detiene el hilo que esta ejecuatando la mesa   
   */
    public void detenerHilo(){
        this.ejecutar=false;
    }
    
    /** Método que activa el hilo de una mesa  
   */
    public void reanudarHilo(){
        this.ejecutar=true;
    }
    
    /** Método que compureba el estado del hilo
     * @return arrancar el hilo
   */
    public boolean getActivo(){
        return this.ejecutar;
    }
    
    /** Método que elimina una mesa   
   */
    public void eliminar(){
        try {
            this.finalize();
        } catch (Throwable ex) {
            Logger.getLogger(HiloCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /**
   * Método que ejecuta el cliente cada vez que se establece una nueva conexion
   */
    public void run(){
        while(ejecutar){
            try{
                iis = new ObjectInputStream(scliente.getInputStream());
                protocol = (Protocolo)iis.readObject();
                String accion = protocol.getAccion();
                if(accion.equals("enviarAdvertencia")){
                    String mensaje = protocol.getArg1();
                    cliente.mostrarAdvert(mensaje);
                }else if(accion.equals("enviarMensaje")){
                    String mensaje = protocol.getArg1();
                    cliente.mostrarMensaje(mensaje);
                }else if(accion.equals("listaGames")){
                    DefaultListModel lista = protocol.getLista();
                    cliente.actualizarListaGames(lista);
                }else if(accion.equals("listaUsers")){
                    DefaultListModel lista = protocol.getLista();
                    mesa.actualizarListaUsers(lista);
                }else if(accion.equals("nuevaRonda")){
                    mesa.nuevaRonda(protocol.getArg1(), protocol.getArg2(), protocol.getArg3());
                }else if(accion.equals("errorMesaPropia")){
                    cliente.errorMesaPropia();
                }else if(accion.equals("errorPartidaComenzada")){
                    cliente.errorPartidaComenzada();
                }else if(accion.equals("errorMesaNoExiste")){
                    cliente.errorMesaNoExiste();
                }else if(accion.equals("enviarDataGame")){
                    String nombrePartida= protocol.getArg1();
                    String nombrePlayer1 = protocol.getArg2();
                    String nombreCreador = protocol.getArg3();
                    cliente.comenzarPartida(nombrePartida, nombrePlayer1, nombreCreador);
                }else if(accion.equals("listaRanking")){
                    cliente.actualizarListaRanking(protocol.getLista());
                }else if(accion.equals("listaTemas")){
                    cliente.actualizarListaTemas(protocol.getLista());
                }else if(accion.equals("finalizarMesa")){
                    mesa.finalizarMesa();
                }else if(accion.equals("numeroConectados")){
                    cliente.actualizarNumeroConectados(protocol.getArg1());
                }

            }catch(Exception ex){
                cliente.mostrarAdvert("[Te has desconectado]");
            }
        }
    }
}