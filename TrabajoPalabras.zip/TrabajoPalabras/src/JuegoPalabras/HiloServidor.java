package JuegoPalabras;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Vector;
import javax.swing.DefaultListModel;

/**
 * Clase que se encarga de gestionar el hilo del servidor con ayuda de Thread
 */
public class HiloServidor extends Thread{
    
    private DataInputStream is;
    private DataOutputStream os;
    private ObjectInputStream iis;
    private ObjectOutputStream oos;
    private IUServidor server;
    private Socket cliente;
    public static Vector<HiloServidor> usuarioActivo = new Vector();
    private String nombre;
    private ObjectOutputStream objs;
    private Protocolo protocol;
    private Protocolo protocolSend;
    
    public HiloServidor(Socket socketCliente, String name, IUServidor serv){
        this.cliente=socketCliente;
        this.nombre=name;
        this.server=serv;
        usuarioActivo.add(this);
        
        enviarATodosMensaje("advertencia", "["+nombre + " se ha conectado]");
        enviarATodosListaRanking();
        enviarATodosListaTemas();
        enviarATodosNumeroConectados();
    }
    /**
    * Método que devuelve el nombre del cliente
    * @return El nombre del cliente
    */
    public String getNombre() {
        return nombre;
    }
    
    
    /**
    * Método que envia los usuarios activos a todos los jugadores conectados
    * @param modo Modo del mensaje que se envia, normal o advertencia
    * @param msj Mensaje de informacion
    */
    public void enviarATodosMensaje(String modo, String msj){
        for(int i=0;i<usuarioActivo.size();i++){
            usuarioActivo.get(i).enviarMensaje(modo, msj);
        }
    }
    
    /**
    * Método que comprueba en que estado se encuentran los usuarios
    * @param modo Modo advertencia, si se ha conectado alguien o Modo normal si un jugador escribe en el chat
    * @param msj Mensaje de informacion
    */
    public void enviarMensaje(String modo, String msj){
        if(modo.equals("normal")){
            try {
                oos = new ObjectOutputStream(cliente.getOutputStream());
                protocolSend = new Protocolo("enviarMensaje", msj);
                oos.writeObject(protocolSend);
            
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
        }else if(modo.equals("advertencia")){
            try {
                oos = new ObjectOutputStream(cliente.getOutputStream());
                protocolSend = new Protocolo("enviarAdvertencia", msj);
                oos.writeObject(protocolSend);
            
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }
    
    /**
    * Método que envia los usuarios conectados a una mesa a todos los jugadores
    * @param mesa Mesa en la que se encuentra el usuario
    */
    public void enviarATodosListaUsers(Mesa mesa){
        for(int i=0;i<mesa.jugadores.size();i++){
            mesa.jugadores.get(i).enviarListaUsers(mesa);
        }
    }
    /**
    * Método que recoge el nombre de todos los jugadores conectados
    * @param mesa mesa en la que se encuentra el usuario
    */
    public void enviarListaUsers(Mesa mesa){
        DefaultListModel modelo = new DefaultListModel();
         
        for(int i=0;i<mesa.jugadores.size();i++){
            PuntosMesaJugador puntos = PuntosMesaJugador.getPuntosMesaJugador(mesa.getNombre(), mesa.jugadores.get(i).getNombre());
            int puntosJugador = 0;
            if(puntos!=null){
                puntosJugador = puntos.getPuntos();
            }
            modelo.addElement(mesa.jugadores.get(i).getNombre()+"     "+puntosJugador+"puntos");
        }
        
        try{
            oos = new ObjectOutputStream(cliente.getOutputStream());
            protocolSend = new Protocolo("listaUsers", modelo);
            oos .writeObject(protocolSend);
            server.escribirTexto(modelo.toString());
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }
    }
    
    /**
     * Método que envia en numero de jugadores conectados
     */
    public void enviarATodosNumeroConectados(){
        for(int i=0;i<HiloServidor.usuarioActivo.size();i++){
            HiloServidor.usuarioActivo.get(i).enviarNumeroConectados();
        }
    }
    
    /**
    * Método que recoge el numero de todos los usuarios conectados
    */
    
    public void enviarNumeroConectados(){
        server.escribirTexto("Enviando a "+this.getNombre()+" "+HiloServidor.usuarioActivo.size()+" conectados");
        try{
            oos = new ObjectOutputStream(cliente.getOutputStream());
            protocolSend = new Protocolo("numeroConectados", ""+HiloServidor.usuarioActivo.size());
            oos .writeObject(protocolSend);
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }
    }
    
    /**
     * Método que envia a los usuarios a una nueva ronda
     */
    public void enviarATodosNuevaRonda(Mesa mesa){
        for(int i=0;i<mesa.jugadores.size();i++){
            mesa.jugadores.get(i).enviarNuevaRonda(mesa);
        }
    }
    
    /**
    * Método que realiza el cambio de cada ronda
    */
    public void enviarNuevaRonda(Mesa mesa){
        String palabra;
        try{
            palabra = mesa.getTema().getPalabra(mesa.getRonda()-1);
        }catch(Exception ex){
            palabra = null;
        }
        
        if(palabra==null){
            if(mesa.getCreador().getNombre().equals(this.getNombre())){
                String mensaje = "";
                for(int i=0;i<mesa.jugadores.size();i++){
                    PuntosMesaJugador puntos = PuntosMesaJugador.getPuntosMesaJugador(mesa.getNombre(), mesa.jugadores.get(i).getNombre());
                    String nombreJugador = puntos.getNombreJugador();
                    int puntosJugador = puntos.getPuntos();
                    String nombreMesa = puntos.getNombreMesa();
                    String nombreTema = mesa.getTema().getNombre();
                    
                    mensaje+="[Tema "+nombreTema+"] [Mesa "+nombreMesa+"] [Jugador "+nombreJugador+"] [Puntos +"+puntosJugador+"puntos]\n";
                }
                enviarATodosMensaje("advertencia", mensaje);
                finalizarMesaTodos(mesa);
            }
        }else{
            try{
                oos = new ObjectOutputStream(cliente.getOutputStream());
                protocolSend = new Protocolo("nuevaRonda", palabra, mesa.getTema().desordenarPalabra(palabra), ""+mesa.getRonda());
                oos .writeObject(protocolSend);
            }catch(Exception ex){
                System.out.println(ex.getMessage());
            }
        }
    }
    
    /**
    * Método que envia a los usuarios al final de la partida con la informacion de la misma
    */
    public void finalizarMesaTodos(Mesa mesa){
        for(int i=0;i<mesa.jugadores.size();i++){
            mesa.jugadores.get(i).finalizarMesa(mesa);
            mesa.jugadores.get(i).enviarListaGames(mesa.getTema());
            mesa.jugadores.get(i).enviarListaRanking();
        }
        try{
            PuntosMesaJugador.eliminarPuntosMesa(mesa.getNombre());
        }catch(Exception ex){
            ex.toString();
        }
        Mesa.mesas.remove(mesa);
    }
    
    /**
    * Método que recopila los datos de la partida de cada jugador
    */
    public void finalizarMesa(Mesa mesa){
        try{
            oos = new ObjectOutputStream(cliente.getOutputStream());
            protocolSend = new Protocolo("finalizarMesa");
            oos .writeObject(protocolSend);
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }
        int puntosAnadir = PuntosMesaJugador.getPuntosMesaJugador(mesa.getNombre(), this.getNombre()).getPuntos();
        int puntosJugador = Jugador.buscarJugador(this.getNombre()).getPuntos();
        Jugador.buscarJugador(this.nombre).setPuntos(puntosJugador+puntosAnadir);
        try{
            Jugador.almacenarJugadoresFichero();
        }catch(Exception ex){
            ex.toString();
        }
        
    }
    
     /**
    * Método que envia a los usuarios los salones con sus temas
    * @param tema tema de cada salon
    */
    public void enviarListaGames(Tema tema){
        DefaultListModel modelo = new DefaultListModel();
            
        for(int i=0;i<Mesa.mesas.size();i++){
            if(Mesa.mesas.get(i).getTema().getNombre().equals(tema.getNombre())){
                modelo.addElement(Mesa.mesas.get(i).getNombre());
            }
        }
        
        try{
            oos = new ObjectOutputStream(cliente.getOutputStream());
            protocolSend = new Protocolo("listaGames", modelo);
            oos .writeObject(protocolSend);
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }
    }
    
    /**
    * Método que envia un mensaje de que ha habido un error y no puedes unirte a la mesa q te has unido
    */
    public void enviarErrorMesaPropia(){ 
        try{
            oos = new ObjectOutputStream(cliente.getOutputStream());
            protocolSend = new Protocolo("errorMesaPropia");
            oos .writeObject(protocolSend);
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }
    }
     /**
    * Método que envia a los usuarios un mensaje de error de que la partida ha comenzado
    */
    public void enviarErrorPartidaComenzada(){ 
        try{
            oos = new ObjectOutputStream(cliente.getOutputStream());
            protocolSend = new Protocolo("errorPartidaComenzada");
            oos .writeObject(protocolSend);
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }
    }
    
     /**
   * Método que envia a los usuarios que la mesa a la que querian acceder ya no existe
   */
    public void enviarErrorMesaNoExiste(){ 
        try{
            oos = new ObjectOutputStream(cliente.getOutputStream());
            protocolSend = new Protocolo("errorMesaNoExiste");
            oos .writeObject(protocolSend);
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }
    }
    /**
    * Método que envia a los usuarios el ranking de puntos 
    */
    public void enviarATodosListaRanking(){
        for(int i=0;i<usuarioActivo.size();i++){
            usuarioActivo.get(i).enviarListaRanking();
        }
    }
     /**
    * Método que recopila los puntos de cada jugador quedandose con los 3 primeros
    */
    public void enviarListaRanking(){
        DefaultListModel modelo = new DefaultListModel();
            
        modelo.addElement(Jugador.devolverPrimero().getNombre()+"  "+Jugador.devolverPrimero().getPuntos()+" puntos");
        modelo.addElement(Jugador.devolverSegundo().getNombre()+"  "+Jugador.devolverSegundo().getPuntos()+" puntos");
        modelo.addElement(Jugador.devolverTercero().getNombre()+"  "+Jugador.devolverTercero().getPuntos()+" puntos");
        
        try{
            oos = new ObjectOutputStream(cliente.getOutputStream());
            protocolSend = new Protocolo("listaRanking", modelo);
            oos .writeObject(protocolSend);
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }
    }
    
     /**
   * Método que envia a los usuarios los posibles temas
   */
    public void enviarATodosListaTemas(){
        for(int i=0;i<usuarioActivo.size();i++){
            usuarioActivo.get(i).enviarListaTemas();
        }
    }
    
     /**
   * Método que recorre todos los temas 
   */
    public void enviarListaTemas(){
        DefaultListModel modelo = new DefaultListModel();
            
        for(int i=0;i<Tema.temas.size();i++){
            modelo.addElement(Tema.temas.get(i).getNombre());
        }
        
        try{
            oos = new ObjectOutputStream(cliente.getOutputStream());
            protocolSend = new Protocolo("listaTemas", modelo);
            oos .writeObject(protocolSend);
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }
    }

     /**
   * Método que busca que el jugador siga conectado a la partida 
   * @param nombre nombre del jugador
   */    
    public static HiloServidor buscarJugador(String nombre){
        HiloServidor jugador = null;
        for(int i=0;i<usuarioActivo.size()&&jugador==null;i++){
            if(usuarioActivo.get(i).nombre.equals(nombre)){
               jugador = usuarioActivo.get(i);
            }
        }
        return jugador;
    }
    
     /**
   * ........................................
   */    
    public void enviarDataGame(String nombrePartida, String nombrePlayer1, String nombreTema){
        try {
            oos = new ObjectOutputStream(cliente.getOutputStream());
            protocolSend = new Protocolo("enviarDataGame", nombrePartida, nombrePlayer1, nombreTema);
            oos.writeObject(protocolSend);

        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
     /**
   * Método que ejecuta el servidor cada vez que se establece una nueva conexion
   */
    public void run(){
        while(true){
            try {
                iis = new ObjectInputStream(cliente.getInputStream());
                protocol = (Protocolo)iis.readObject();
                String comando = protocol.getAccion();
                if(comando.equals("close")){
                    break;
                }else if(comando.equals("crearMesa")){
                    Tema tema = Tema.getTemaByName(protocol.getArg1());
                    Mesa mesa = new Mesa(cliente, tema, this);
                    enviarListaGames(tema);
                    server.escribirTexto("Nueva mesa ["+mesa.getNombre()+"] ["+mesa.getTema().getNombre()+"] ["+this.getNombre()+"]");
                    this.enviarDataGame(mesa.getNombre(), this.getNombre(), mesa.getCreador().getNombre());
                    enviarATodosListaUsers(mesa);
                    String palabra = tema.getPalabra(mesa.getRonda());
                    server.escribirTexto("Palabra ordenada: " + palabra + " Palabra desordenada: " + tema.desordenarPalabra(palabra));
                }else if(comando.equals("unirseMesa")){
                    Mesa mesa = null;
                    try{
                        mesa = Mesa.getMesa(protocol.getArg1());
                    }catch(Exception ex){
                        mesa = null;
                    }
                    
                    if(mesa!=null){
                       boolean encontrado = false;
                        for(int i=0;i<mesa.jugadores.size();i++){
                            if(mesa.jugadores.get(i).getNombre()==this.getNombre()){
                                encontrado = true;
                            }
                        }
                        if(!encontrado){
                            if(mesa.getRonda()==0){
                                mesa.addPlayer(this);
                                enviarListaGames(mesa.getTema());
                                this.enviarDataGame(mesa.getNombre(), this.getNombre(), mesa.getTema().getNombre());
                                enviarATodosListaUsers(mesa);
                                server.escribirTexto("["+this.getNombre()+" se ha unido a la mesa "+mesa.getNombre()+"]");
                            }else{
                                enviarErrorPartidaComenzada();
                            }
                        }else{
                            enviarErrorMesaPropia();
                        } 
                    }else{
                        enviarErrorMesaNoExiste();
                    }
                    
                }else if(comando.equals("listaMesas")){
                    String nombreTema = protocol.getArg1();
                    Tema tema = Tema.getTemaByName(nombreTema);
                    enviarListaGames(tema);
                }else if(comando.equals("envioMensaje")){
                    enviarATodosMensaje("normal", protocol.getArg1());
                    server.escribirTexto(nombre+" escribió ["+protocol.getArg1()+"]");
                }else if(comando.equals("comenzarRonda")){
                    Mesa mesa = Mesa.getMesa(protocol.getArg1());
                    mesa.setRonda(mesa.getRonda()+1);
                    enviarATodosNuevaRonda(mesa);
                }else if(comando.equals("acertar")){
                    Mesa mesa = Mesa.getMesa(protocol.getArg1());
                    Mesa.puntosMesa(protocol.getArg1(), protocol.getArg2(), Integer.parseInt(protocol.getArg3()));
                    enviarATodosListaUsers(mesa);  
                }else
                    System.out.println("error");
            } catch(Exception ex){
                break;
            }
        }
        usuarioActivo.removeElement(this);
        enviarATodosMensaje("advertencia", "["+this.nombre+" se ha desconectado]");
        enviarATodosNumeroConectados();
        server.escribirTexto("El usuario "+this.nombre+" se ha desconectado");
        
        try{
            cliente.close();
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }
        
    }

    
    

}
