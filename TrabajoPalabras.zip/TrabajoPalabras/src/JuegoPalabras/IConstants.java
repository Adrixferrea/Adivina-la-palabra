package JuegoPalabras;

/**
 * Interfaz que se encarga de unas constantes
 * como son el puerto y el host, que se usan bastante
 */
public interface IConstants {
    public static final int PORT = 6011;
    public static final String HOST = "127.0.0.1";
}
