/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JuegoPalabras;

import java.awt.Color;
import java.io.DataOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import javax.swing.text.AttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;
import java.awt.event.KeyEvent;

/**
 * Clase que se encarga de la interfaz de un jugador
 * @author luisG
 */
public class IUPrincipal extends javax.swing.JFrame{
    
    private Socket cliente;
    private DataOutputStream os;
    private ObjectOutputStream oos;
    private ObjectInputStream iis;
    private String mensaje;
    private String nick;
    private String pass;
    private HiloCliente hilo;
    private Protocolo protocol;
    private Color colorUsuarioChat;
    private String peticionNombrePlayer1;
    
    /**
    * Método que se encarga de iniciar la interfaz del jugador, el nick de 
    * usuario y la contraseña
    */
    public void initManualComponents(){
        this.setLayout(null);
        this.setResizable(false);
        this.setLocationRelativeTo(null); 
        nick = JOptionPane.showInputDialog(("Nick: "));
        if(nick.equals(""))
            System.exit(0);
        txtNick.setText(nick);
        jTextField1.disable();
        pass = JOptionPane.showInputDialog(("Passwd: "));
        if(pass.equals(""))
            System.exit(0);
        this.setVisible(true);
        this.campotexto.setFocusable(false);
        calcularColorUsuario();
    }
    
    public IUPrincipal(){
        initComponents();
        initManualComponents();
        try{
            cliente = new Socket("127.0.0.1", 9999);
            oos = new ObjectOutputStream(cliente.getOutputStream());
            iis = new ObjectInputStream(cliente.getInputStream());
            protocol= new Protocolo("connect", nick, pass);
            oos.writeObject(protocol);

            Protocolo protocolRecibido = (Protocolo)iis.readObject();
            if(protocolRecibido.getAccion().equals("AlreadyConnected")){
                JOptionPane.showMessageDialog(this, "El usuario "+nick+" ya tiene una sesión activa");
                this.setVisible(false);
                System.exit(0);
            }
            protocolRecibido = (Protocolo)iis.readObject();
            if(protocolRecibido.getAccion().equals("NoRegistrado")){
                hilo = new HiloCliente(cliente, this);
                hilo.start();
            }else if(protocolRecibido.getAccion().equals("YaRegistrado")){
                    protocolRecibido = (Protocolo)iis.readObject();
                    if(protocolRecibido.getAccion().equals("CorrectPassword")){
                        hilo = new HiloCliente(cliente, this);
                        hilo.start();
                    }else if(protocolRecibido.getAccion().equals("WrongPassword")){
                        JOptionPane.showMessageDialog(this, "Contraseña incorrecta");
                        this.setVisible(false);
                        System.exit(0);
                    }
            }
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }
    }

    /**
    * Método que devuelve el nombre del jugador
    * @return nombre del jugador
    */
    public String getNick() {
        return nick;
    }

    /**
    * Método que devuelve la peticion que ha hecho el jugador
    * @return peticion del jugador
    */
    public String getPeticionNombrePlayer1() {
        return peticionNombrePlayer1;
    }

    /**
    * Método que calcula el color del usuario para que
    * cada usuario salga con un color diferente en el chat
    */
    public void calcularColorUsuario(){
        int r = (int)(Math.random()*255)+1;
        int g = (int)(Math.random()*255)+1;
        int b = (int)(Math.random()*255)+1;
        colorUsuarioChat= new Color(r,g,b);
    }
    
    /**
    * Método que muestra el mensaje del jugador por el chat
     * @param msj mensaje del jugador
    */
    public void mostrarMensaje(String msj){
        String[] token;
        token = msj.split(":");
        appendToPane(token[0]+":", colorUsuarioChat);
        appendToPane(token[1]+"\n", Color.BLACK);
    }
    
    /**
    * Método que muestra al jugador por el chat que se ha conectado un jugador
     * @param msj mensaje de conexion de otro jugador
    */
    public void mostrarAdvert(String msj){
        appendToPane(msj+"\n", Color.GRAY);
    }
    
    /**
    * Método que añade a la interfaz el mensaje y el color del jugador
     * @param msg mensaje 
     * @param c color
    */
    private void appendToPane(String msg, Color c)
    {
        StyleContext sc = StyleContext.getDefaultStyleContext();
        AttributeSet aset = sc.addAttribute(SimpleAttributeSet.EMPTY, StyleConstants.Foreground, c);

        aset = sc.addAttribute(aset, StyleConstants.FontFamily, "Arial Rounder MT Bold");
        aset = sc.addAttribute(aset, StyleConstants.Alignment, StyleConstants.ALIGN_JUSTIFIED);

        int len = campotexto.getDocument().getLength();
        campotexto.setCaretPosition(len);
        campotexto.setCharacterAttributes(aset, false);
        campotexto.replaceSelection(msg);
    }
    
    /**
    * Método que actualiza el numero de jugadores conectados
     * @param numero numero de jugadores conectados
    */
    public void actualizarNumeroConectados(String numero){
        this.jTextField1.setText(numero+" conectados");
    }
    
    /**
    * Método que actualiza la lista de juegos
     * @param modelo modelo para cambiarlo
    */
    public void actualizarListaGames(DefaultListModel modelo){
        this.jListGames.setModel(modelo);
    }
    
    /**
    * Método que actualiza el ranking del top3 de jugadores
     * @param modelo modelo para cambiarlo
    */
    public void actualizarListaRanking(DefaultListModel modelo){
        this.jListRanking.setModel(modelo);
    }
    
    /**
    * Método que actualiza la lista de temas
     * @param modelo modelo para cambiarlo
    */
    public void actualizarListaTemas(DefaultListModel modelo){
        this.jList1.setModel(modelo);
    }
    
    /**
    * Método que envia el mensaje al jugador
    */
    public void enviarMensaje(){
        if(hilo.getActivo()){
            if(!txt_mensaje.getText().isEmpty()){
                try{
                    oos = new ObjectOutputStream(cliente.getOutputStream());
                    protocol = new Protocolo("envioMensaje", (nick+": "+ this.txt_mensaje.getText()));
                    oos.writeObject(protocol);
                    this.txt_mensaje.setText("");
                }catch(Exception ex){
                    System.out.println(ex.toString());
                }
            }else
                JOptionPane.showMessageDialog(this, "Mensaje vacío");
        }else
        JOptionPane.showMessageDialog(this, "Estas desconectado");
    }                         
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLayeredPane1 = new javax.swing.JLayeredPane();
        jLabel1 = new javax.swing.JLabel();
        btn_enviarMensaje = new javax.swing.JButton();
        txt_mensaje = new javax.swing.JTextField();
        labelNick = new javax.swing.JLabel();
        txtNick = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        campotexto = new javax.swing.JTextPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        jListGames = new javax.swing.JList<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jListRanking = new javax.swing.JList<>();
        jScrollPane6 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList();
        jLabel7 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));

        jLayeredPane1.setBackground(new java.awt.Color(255, 51, 255));
        jLayeredPane1.setLayout(new java.awt.BorderLayout());
        jLayeredPane1.add(jLabel1, java.awt.BorderLayout.CENTER);

        btn_enviarMensaje.setText("Send");
        btn_enviarMensaje.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_enviarMensajeActionPerformed(evt);
            }
        });

        txt_mensaje.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txt_mensaje.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_mensajeActionPerformed(evt);
            }
        });
        txt_mensaje.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_mensajeKeyPressed(evt);
            }
        });

        txtNick.setFont(new java.awt.Font("Yu Gothic", 0, 18)); // NOI18N
        txtNick.setForeground(new java.awt.Color(255, 255, 255));
        txtNick.setText("jLabel2");

        jScrollPane3.setViewportView(campotexto);

        jListGames.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jListGamesMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jListGames);

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Temas disponibles:");

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Mesas activas:");

        jListRanking.setFont(new java.awt.Font("Tahoma", 0, 30)); // NOI18N
        jScrollPane5.setViewportView(jListRanking);

        jList1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jList1MouseClicked(evt);
            }
        });
        jScrollPane6.setViewportView(jList1);

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/JuegoPalabras/trofeoOro.png"))); // NOI18N

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/JuegoPalabras/trofeoPlata.png"))); // NOI18N

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/JuegoPalabras/trofeoBronce.png"))); // NOI18N

        jButton1.setText("Nueva Mesa");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Top de jugadores:");

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Chat:");

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(txtNick)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(labelNick, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(34, 34, 34))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGap(46, 46, 46)
                                .addComponent(jLabel5)
                                .addGap(206, 206, 206))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(40, 40, 40)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(197, 197, 197))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                    .addComponent(jLabel7)
                                                    .addComponent(jLabel6)
                                                    .addComponent(jLabel8))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addComponent(txt_mensaje, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGap(18, 18, 18)
                                                    .addComponent(btn_enviarMensaje))
                                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 308, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(9, 9, 9)))))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 326, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel2)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGap(29, 29, 29)
                                    .addComponent(jLabel3)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 325, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)))
                .addComponent(jLayeredPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(txtNick)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLayeredPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(366, 366, 366))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jLabel6)
                                                .addGap(11, 11, 11)
                                                .addComponent(jLabel8))
                                            .addComponent(jScrollPane5))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel4)
                                            .addComponent(jTextField1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 132, Short.MAX_VALUE)
                                        .addGap(18, 18, 18)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jLabel3)
                                            .addComponent(jButton1))
                                        .addGap(18, 18, 18)
                                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txt_mensaje, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btn_enviarMensaje, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(labelNick)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        jButton1.getAccessibleContext().setAccessibleName("nuevaMesa");

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_mensajeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_mensajeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_mensajeActionPerformed

    private void btn_enviarMensajeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_enviarMensajeActionPerformed
        enviarMensaje();
    }//GEN-LAST:event_btn_enviarMensajeActionPerformed

    private void txt_mensajeKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_mensajeKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER){
            enviarMensaje();
	}
    }//GEN-LAST:event_txt_mensajeKeyPressed

    private void jList1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jList1MouseClicked
        if(hilo.getActivo()){
            protocol = new Protocolo("listaMesas", jList1.getSelectedValue().toString());
            try{
                oos = new ObjectOutputStream(cliente.getOutputStream()); 
                oos.writeObject(protocol);
            }catch(Exception ex){
                System.out.println(ex.toString());
            }
        }
    }//GEN-LAST:event_jList1MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        if(jList1.getSelectedValue()!=null){
           protocol = new Protocolo("crearMesa", jList1.getSelectedValue().toString(), txtNick.getText());
            try{
                oos = new ObjectOutputStream(cliente.getOutputStream());
                oos.writeObject(protocol);
            }catch(Exception ex){
                System.out.println(ex.toString());
            } 
        }else{
            JOptionPane.showMessageDialog(this, "Debes seleccionar un tema");
        }
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jListGamesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jListGamesMouseClicked
        // TODO add your handling code here:
        int respuesta =JOptionPane.showConfirmDialog(this, "¿Deseas unirte a la mesa: " + jListGames.getSelectedValue().toString() + "?");
        if(respuesta==0){
            protocol = new Protocolo("unirseMesa", jListGames.getSelectedValue().toString());
            try{
                oos = new ObjectOutputStream(cliente.getOutputStream());
                oos.writeObject(protocol);
            }catch(Exception ex){
                System.out.println(ex.toString());
            }
        }
    }//GEN-LAST:event_jListGamesMouseClicked

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    /**
    * Método que hace comenzar la partida de un tema
     * @param nombrePartida nombre de la partida
     * @param nombrePlayer1 nombre del jugador que no es el creador
     * @param nombreCreador nombre del jugador que ha creado la partida
    */
    public void comenzarPartida(String nombrePartida, String nombrePlayer1, String nombreCreador){
        IUMesa partida = new IUMesa(this, cliente, nombrePartida, nombrePlayer1, nombreCreador);  
        hilo.setMesa(partida);
    }
    
    /**
    * Método que envia un mensaje de que ha habido un error y no puedes unirte a la mesa q te has unido
    */
    public void errorMesaPropia(){
        JOptionPane.showMessageDialog(this, "No puedes unirte a una mesa a la que ya te has unido");
    }
    
    /**
    * Método que envia a los usuarios un mensaje de error de que la partida ha comenzado
    */
    public void errorPartidaComenzada(){
        JOptionPane.showMessageDialog(this, "No puedes unirte a la mesa porque ya ha comenzado");
    }
    
    /**
    * Método que envia a los usuarios que la mesa a la que querian acceder ya no existe
    */
    public void errorMesaNoExiste(){
        JOptionPane.showMessageDialog(this, "La partida a la que intentas unirte ya ha finalizado, actualiza las mesas");
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(IUPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(IUPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(IUPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(IUPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        IUPrincipal g1 = new IUPrincipal();
   
    }
    

    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_enviarMensaje;
    private javax.swing.JTextPane campotexto;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLayeredPane jLayeredPane1;
    private javax.swing.JList jList1;
    private javax.swing.JList<String> jListGames;
    private javax.swing.JList<String> jListRanking;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JLabel labelNick;
    private javax.swing.JLabel txtNick;
    private javax.swing.JTextField txt_mensaje;
    // End of variables declaration//GEN-END:variables


}
