package JuegoPalabras;

import java.awt.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;
import javax.swing.*;

/**
 * Clase que se encarga de la interfaz del servidor
 */
class IUServidor extends JFrame{
    
    private JTextArea areaDeTexto;
    
    /**
    * Método que se encarga de iniciar la interfaz de una manera determinada
    */    
    public void initComponents(){
        this.setBounds(1200,300,500,500);
        JPanel milamina = new JPanel();
        milamina.setLayout(new BorderLayout());
        areaDeTexto = new JTextArea();
        areaDeTexto.setFocusable(false);
        milamina.add(areaDeTexto, BorderLayout.CENTER);
        this.add(milamina);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }
    
    public IUServidor(){
        initComponents();
        File regJugadores = new File("RegistroDeJugadores.txt");
        File regTemas = new File("RegistroDeTemas.txt");
        try{
            ServerSocket servidor = new ServerSocket(9999);
            escribirTexto("Servidor Iniciado");
            
            while(true){
                Socket cliente = servidor.accept();
                escribirTexto("Cliente aceptado desde la direccion: "+cliente.getInetAddress().getHostAddress());
                ObjectInputStream iis = new ObjectInputStream(cliente.getInputStream());
                ObjectOutputStream oss = new ObjectOutputStream(cliente.getOutputStream());
                Protocolo protocol = (Protocolo)iis.readObject();
                String comando = protocol.getAccion();
                if(comando.equals("connect")){
                    String usuario = protocol.getArg1();
                    String contrasena = protocol.getArg2();

                    Jugador.vaciarListaJugadores();
                    cargarJugadores(regJugadores);
                    Tema.vaciarListaTemas();
                    cargarTemas(regTemas);
                    HiloServidor h1 = HiloServidor.buscarJugador(usuario);
                    if(h1!=null){
                        Protocolo protocolHilo= new Protocolo("AlreadyConnected");
                        oss.writeObject(protocolHilo);
                    }else{
                        Protocolo protocolHilo= new Protocolo("NotConnected");
                        oss.writeObject(protocolHilo);
                        Jugador j1 = Jugador.buscarJugador(usuario);
                        if(j1==null){
                            Protocolo protocolPass= new Protocolo("NoRegistrado");
                            oss.writeObject(protocolPass);
                            j1=new Jugador(usuario, contrasena, 0);
                            System.out.println("registrado");
                            HiloServidor hilo = new HiloServidor (cliente, j1.getNombre(), this);
                            hilo.start();
                            Jugador.almacenarJugadoresFichero();
                            escribirTexto(j1.getNombre()+" se ha conectado");
                        }else{
                            Protocolo protocolPass= new Protocolo("YaRegistrado");
                            oss.writeObject(protocolPass);
                            System.out.println("logueado");
                            if(contrasena.equals(j1.getContrasena())){
                                protocolPass= new Protocolo("CorrectPassword");
                                oss.writeObject(protocolPass);
                                HiloServidor hilo = new HiloServidor (cliente, j1.getNombre(), this);
                                hilo.start();
                                Jugador.almacenarJugadoresFichero();
                                escribirTexto(j1.getNombre()+" se ha conectado");
                            }else{
                                protocolPass= new Protocolo("WrongPassword");
                                oss.writeObject(protocolPass);
                            }
                        }   
                    }
                }
            }
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }
                
    }
    
    /**
    * Método que escribe un texto con salto de linea
    * @param texto texto a escribir
    */
    public void escribirTexto(String texto){
        areaDeTexto.append(" "+texto+"\n");
    }
    
    /**
    * Método que escribe un texto sin salto de linea
    * @param texto texto a escribir
    */
    public void escribirTextoSinSaltoLn(String texto){
        areaDeTexto.append(" "+texto);
    }
    
    /**
    * Método que carga los jugadores del archivo RegistroDeJugadores.txt
    * @param regJugadores archivo de RegistroDeJugadores.txt
    * @throws java.io.FileNotFoundException
    * @throws java.io.IOException
    */
    public void cargarJugadores(File regJugadores) throws FileNotFoundException, IOException{
        FileReader fr = new FileReader(regJugadores);
        BufferedReader br = new BufferedReader(fr);
        String linea;
        
        while((linea=br.readLine())!=null){
            String token[] = linea.split(";");
            Jugador c1 = new Jugador(token[0], token[1], Integer.parseInt(token[2]));
        }
    }
    
    /**
    * Método que carga los temas de las salas de los que se van a crear las mesas
    * @param regTemas archivo de RegistroDeTemas.txt
    * @throws java.io.FileNotFoundException
    * @throws java.io.IOException
    */
    public  void cargarTemas(File regTemas) throws FileNotFoundException, IOException{
        FileReader fr = new FileReader(regTemas);
        BufferedReader br = new BufferedReader(fr);
        String linea;
        
        while((linea=br.readLine())!=null){
            String token[] = linea.split(";");
            Vector<String> palabras = new Vector();
            for(int i=1;i<token.length;i++){
                palabras.add(token[i]);
            }
            Tema t1 = new Tema(token[0], palabras);    
        }   
    }
    

}
