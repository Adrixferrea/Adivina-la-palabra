package JuegoPalabras;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Clase que se encarga de los jugadores conectados
 */
public class Jugador {
    private String nombre;
    private String contrasena;
    private int puntos;
    public static ArrayList<Jugador> jugadores = new ArrayList<>();

    public Jugador(String nombre, String contrasena, int puntos) {
        this.nombre = nombre;
        this.puntos = puntos;
        this.contrasena=contrasena;
        jugadores.add(this);
        try{  
            almacenarJugadoresFichero();
        }catch(IOException e){};
    }

    /**
    * Método que devuelve el nombre del jugador
    * @return nombre del jugador
    */
    public String getNombre() {
        return nombre;
    }

    /**
    * Método que devuelve los puntos del jugador
    * @return puntos del jugador
    */
    public int getPuntos() {
        return puntos;
    }

    /**
    * Método que devuelve la contraseña del jugador
    * @return contraseña del jugador
    */
    public String getContrasena() {
        return contrasena;
    }
    
    /**
    * Método que pone el nombre de usuario del jugador
     * @param nombre nombre del jugador
    */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
    * Método que pone el los puntos del jugador
     * @param puntos puntos del jugador
    */
    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }

    /**
    * Método que pone en el RegistroDeJugadores.txt el nombre del jugador, su contraseña y sus puntos
    */
    @Override
    public String toString() {
        return nombre + ";" + contrasena + ";" + puntos;
    }
    
    /**
    * Método que almacena a los jugadores en el fichero RegistroDeJugadores.txt
     * @throws java.io.FileNotFoundException
     * @throws java.io.IOException
    */
    public static void almacenarJugadoresFichero() throws FileNotFoundException, IOException{
        File regJugadores = new File("RegistroDeJugadores.txt");
        
        try{
            FileWriter fw = new FileWriter(regJugadores);
            BufferedWriter bw = new BufferedWriter(fw);
            
            for(Jugador cont: jugadores){
                bw.write(cont.toString());
                bw.newLine();
            }
            
            bw.close();
            fw.close();
        }catch(IOException e){
            System.out.println(e.toString());
        }
    }
    
    /**
    * Método que busca un jugador a partir de su nombre de usuario
     * @param nombre nombre del usuario del jugador
     * @return jugador con su nombre de usuario
    */
    public static Jugador buscarJugador(String nombre){
        Jugador j1 = null;
        for(Jugador player: jugadores){
            if(j1==null&&player.getNombre().equals(nombre)){
                j1=player;
            }
        }
        return j1;
    }
    
    /**
    * Método que vacia la lista de los jugadores
    */
    public static void vaciarListaJugadores(){
        jugadores.removeAll(jugadores);
    }
    
    /**
    * Método que devuelve al top1 del ranking
     * @return jugador top1 del ranking
    */
    public static Jugador devolverPrimero(){
        Jugador j1= jugadores.get(0);
        for(Jugador player: jugadores){
            if(player.getPuntos()>j1.getPuntos())
                j1=player;
        }
        return j1;
    }
    
    /**
    * Método que devuelve al top2 del ranking
     * @return jugador top2 del ranking
    */
    public static Jugador devolverSegundo(){
        Jugador j1= jugadores.get(0);
        for(Jugador player: jugadores){
            if(!player.equals(devolverPrimero())){
                if(player.getPuntos()>j1.getPuntos())
                    j1=player;
            }
        }
        return j1;
    }
    
    /**
    * Método que devuelve al top3 del ranking
     * @return jugador top3 del ranking
    */
    public static Jugador devolverTercero(){
        Jugador j1= jugadores.get(0);
        for(Jugador player: jugadores){
            if(!player.equals(devolverPrimero())&&!player.equals(devolverSegundo())){
                if(player.getPuntos()>j1.getPuntos())
                    j1=player;
            }
        }
        return j1;
    }

}
