package JuegoPalabras;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Vector;

/**
 * Clase que se encarga de las mesas de cada tema
 */
public class Mesa{
    
    private boolean finalizado = false;
    private String ganador;
    private ObjectInputStream iis;
    private ObjectOutputStream oos;
    private Protocolo protocol;
    private IUServidor server;
    public Socket cliente;
    public Tema tema;
    public int ronda;
    public static Vector<Mesa> mesas = new Vector();
    public static Vector<Mesa> gamesFinalizados = new Vector();
    public Vector<HiloServidor> jugadores = new Vector();
    public String nombre;
    private static int numeroPartida;
    private ObjectOutputStream objs;
    
    public Mesa(Socket socketCliente, Tema tema, HiloServidor jugador1){
        numeroPartida++;
        ronda=0;
        this.cliente=socketCliente;
        this.nombre="Mesa"+numeroPartida;
        this.tema=tema;
        mesas.add(this);
        jugadores.add(jugador1);
        
        jugador1.enviarMensaje("advertencia", "Has iniciado una mesa con temática "+tema.getNombre());
    }
    
    /**
    * Método que añade un jugador a conectado
     * @param jugador jugador conectado
    */
    public void addPlayer(HiloServidor jugador){
        jugadores.add(jugador);
    }
    
    /**
    * Método que devuelve el nombre de la mesa
    * @return nombre del jugador
    */
    public String getNombre(){
        return this.nombre;
    }
    
    /**
    * Método que devuelve el tema de la mesa(colores,animales,etc)
    * @return tema
    */
    public Tema getTema(){
        return this.tema;
    }
    
    /**
    * Método que devuelve la ronda que se llega en la sala
    * @return ronda
    */
    public int getRonda(){
        return this.ronda;
    }
    
    /**
    * Método que pone la ronda que se llega en la mesa
     * @param numeroRonda numero de la ronda
    */
    public void setRonda(int numeroRonda){
        this.ronda = numeroRonda;
    }
    
    /**
    * Método que devuelve el creador de la mesa
     * @return creador de la mesa
    */
    public HiloServidor getCreador(){
        return this.jugadores.get(0);
    }
    
    /**
    * Método que devuelve la mesa del tema
     * @param nombreMesa nombre de la mesa(Mesa1,Mesa2,etc)
     * @return mesa del tema
    */
    public static Mesa getMesa(String nombreMesa){
        Mesa mesa = null;
        for(int i=0;i<mesas.size();i++){
            if(mesas.get(i).getNombre().equals(nombreMesa)){
                mesa = mesas.get(i);
            }
        }
        return mesa;
    }
    
    /**
    * Método que devuelve la mesa del tema
     * @param nombreMesa nombre de la mesa(Mesa1,Mesa2,etc)
     * @param nombreJugador nombre de usuario del jugador
     * @param puntos puntos que ha conseguido
     * @throws java.io.FileNotFoundException
     * @throws java.io.IOException
    */
    public static void puntosMesa(String nombreMesa, String nombreJugador, int puntos) throws FileNotFoundException, IOException{
        File regPuntos = new File("RegistroDePuntos.txt");
        FileReader fr = new FileReader(regPuntos);
        BufferedReader br = new BufferedReader(fr);
        String linea;
        int puntosTotales = 0;
        boolean encontrado = false;
        
        PuntosMesaJugador.vaciarListaPuntos();
        while((linea=br.readLine())!=null){
            String token[] = linea.split(";");
            PuntosMesaJugador datos = new PuntosMesaJugador(token[0], token[1], Integer.parseInt(token[2]));
            
            if(token[0].equals(nombreMesa) && token[1].equals(nombreJugador)){
                encontrado = true;
                datos.setPuntos(datos.getPuntos()+puntos);
            }  
        }
        
        if(!encontrado){
            PuntosMesaJugador datos = new PuntosMesaJugador(nombreMesa, nombreJugador, puntos);   
        }
        PuntosMesaJugador.almacenarPuntosMesaJugadorFichero();
    }
    
}
