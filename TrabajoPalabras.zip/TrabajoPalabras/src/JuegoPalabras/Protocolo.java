package JuegoPalabras;

import java.io.Serializable;
import javax.swing.DefaultListModel;

/**
 * Clase que se encarga de los protocolos de la aplicacion
 */
public class Protocolo implements Serializable{
    
    private String accion;
    private String arg1;
    private String arg2;
    private String arg3;
    private DefaultListModel lista;

    public Protocolo(String comando, String arg1) {
        this.accion = comando;
        this.arg1 = arg1;
    }

    public Protocolo(String comando, String arg1, String arg2) {
        this.accion = comando;
        this.arg1 = arg1;
        this.arg2 = arg2;
    }
    

    public Protocolo(String comando, String arg1, String arg2, String arg3) {
        this.accion = comando;
        this.arg1 = arg1;
        this.arg2 = arg2;
        this.arg3 = arg3;
    }

    public Protocolo(String comando) {
        this.accion = comando;
    }

    /**
    * Método que devuelve el argumento1
    * @return argumento1
    */
    public String getArg1() {
        return arg1;
    }
    
    /**
    * Método que devuelve el argumento2
    * @return argumento2
    */
    public String getArg2() {
        return arg2;
    }

    /**
    * Método que devuelve el argumento3
    * @return argumento3
    */
    public String getArg3() {
        return arg3;
    }
    
    
    
    

    public Protocolo(String comando, DefaultListModel lista) {
        this.accion = comando;
        this.lista = lista;
    }

    public DefaultListModel getLista() {
        return lista;
    }
    
    public String getAccion() {
        return accion;
    }
    
    


    
    
}
