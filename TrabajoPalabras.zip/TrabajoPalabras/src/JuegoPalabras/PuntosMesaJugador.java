package JuegoPalabras;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Vector;

/**
 * Clase que se encarga de obtener los puntos de la mesa
 * de cada jugador en ella
 */
public class PuntosMesaJugador{
    
    private int puntos;
    private String nombreMesa;
    private String nombreJugador;
    public static Vector<PuntosMesaJugador> puntosMesaJugador = new Vector();
    
    
    public PuntosMesaJugador(String nombreMesa, String nombreJugador, int puntos){
        this.nombreMesa = nombreMesa;
        this.nombreJugador = nombreJugador;
        this.puntos = puntos;
        puntosMesaJugador.add(this);
    }
    
    /**
    * Método que devuelve el nombre de la mesa
    * @return El nombre de la mesa
    */
    public String getNombreMesa(){
        return this.nombreMesa;
    }
    
    /**
    * Método que devuelve el nombre del jugador de la mesa
    * @return El nombre del jugador
    */
    public String getNombreJugador(){
        return this.nombreJugador;
    }
    
    /**
    * Método que devuelve los puntos de los jugadores de la mesa
    * @return Los puntos de los jugadores
    */
    public int getPuntos(){
        return this.puntos;
    }
    
    /**
    * Método que pone los puntos a los jugadores de la mesa
     * @param puntos puntos de los jugadores
    */
    public void setPuntos(int puntos){
        this.puntos = puntos;
    }
    
    /**
    * Método que devuelve los puntos de los jugadores de la mesa
     * @param nombreMesa nombre de la mesa
     * @param nombreJugador nombre del jugador
     * @return puntos de los jugadores
    */
    public static PuntosMesaJugador getPuntosMesaJugador(String nombreMesa, String nombreJugador){
        PuntosMesaJugador datos = null;
        for(int i=0;i<puntosMesaJugador.size();i++){
            if(puntosMesaJugador.get(i).getNombreJugador().equals(nombreJugador) && puntosMesaJugador.get(i).getNombreMesa().equals(nombreMesa)){
                datos = puntosMesaJugador.get(i);
            }
        }
        return datos;
    }
    
    /**
    * Método que elimina los puntos de los jugadores de la mesa
     * @param nombreMesa nombre de la mesa
     * @throws java.io.FileNotFoundException
     * @throws java.io.IOException
    */
    public static void eliminarPuntosMesa(String nombreMesa) throws FileNotFoundException, IOException{
        for(int i=0;i<puntosMesaJugador.size();i++){
            if(puntosMesaJugador.get(i).getNombreMesa().equals(nombreMesa)){
                System.out.println("Eliminado "+ puntosMesaJugador.get(i).getNombreJugador() + " " + puntosMesaJugador.get(i).getNombreMesa());
                puntosMesaJugador.remove(puntosMesaJugador.get(i));
                i--;
            }
        }
        almacenarPuntosMesaJugadorFichero();
    }
    
    /**
    * Método que almacena los puntos de los jugadores de la mesa en RegistroDePuntos.txt
     * @throws java.io.FileNotFoundException
     * @throws java.io.IOException
    */
    public static void almacenarPuntosMesaJugadorFichero() throws FileNotFoundException, IOException{
        File regPuntos = new File("RegistroDePuntos.txt");
        
        try{
            FileWriter fw = new FileWriter(regPuntos);
            BufferedWriter bw = new BufferedWriter(fw);
            
            for(PuntosMesaJugador cont: puntosMesaJugador){
                bw.write(cont.toString());
                bw.newLine();
            }
            
            bw.close();
            fw.close();
        }catch(IOException e){
            System.out.println(e.toString());
        }
    }
    
    /**
    * Método que dice por el chat el nombre de la mesa, el nombre de los jugadores y los puntos 
    */
    @Override
    public String toString() {
        return nombreMesa + ";" + nombreJugador + ";" + puntos + ";";
    }
    
    /**
    * Método que vacia los puntos de los jugadores de la mesa en RegistroDePuntos.txt
    */
    public static void vaciarListaPuntos(){
        puntosMesaJugador.removeAll(puntosMesaJugador);
    }
    


}
