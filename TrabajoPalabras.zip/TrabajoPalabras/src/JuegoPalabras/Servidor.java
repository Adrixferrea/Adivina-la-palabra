package JuegoPalabras;

import java.io.File;
import java.io.IOException;

/**
 * Clase ejecutable que se encarga de ejecutar el servidor
 * y obtiene los archivos RegistroDeJugadores.txt y
 * RegistroDePuntos.txt, y este ultimo lo elimina y lo crea de nuevo
 */
public class Servidor {
    
    public static void main(String[] args) throws IOException{
        
        File regJugadores = new File("RegistroDeJugadores.txt");
        if(!regJugadores.exists())
            regJugadores.createNewFile();
        
        File regPuntos = new File("RegistroDePuntos.txt");
        regPuntos.delete();
        regPuntos.createNewFile();
        
        IUServidor miServer= new IUServidor();
    }
    


    

}
