/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JuegoPalabras;

import java.util.Random;
import java.util.Vector;

/**
 * Clase que se encarga del tema de la sala y tambien de desordenar las palabras
 * @author luisG
 */
public class Tema {
    public String nombre;
    public static Vector<Tema> temas = new Vector();
    public Vector<String> palabras = new Vector();
    
    public Tema(String nombre, Vector<String> palabras){
        this.nombre = nombre;
        this.palabras = palabras;
        temas.add(this);
    }
    
    /**
    * Método que devuelve el nombre del cliente
    * @return El nombre del tema
    */
    public String getNombre(){
        return this.nombre;
    }
    
    /**
    * Método que vacia la lista de los temas
    */
    public static void vaciarListaTemas(){
        temas.removeAll(temas);
    }
    
    /**
    * Método que obtiene el nombre del tema
     * @param nombreTema nombre del tema(colores,animales,etc)
     * @return tema tema de la sala 
    */
    public static Tema getTemaByName(String nombreTema){
        Tema tema = null;
        for(int i=0;i<temas.size();i++){
            if(temas.get(i).getNombre().equals(nombreTema)){
                tema = temas.get(i);
            }
        }
        return tema;
    }
    
    /**
    * Método que obtiene las palabras del tema
     * @param numero posicion que ocupa la palabra
     * @return palabra
    */
    public String getPalabra(int numero){
        String palabra = palabras.get(numero);
        return palabra;
    }
    
    /**
    * Método que desordena las palabras
     * @param palabra las palabras del tema
     * @return palabra palabra desordenada
    */
    public String desordenarPalabra(String palabra){
        char[] palabraChar = palabra.toCharArray();
        int index;
        Random random = new Random();
        for (int i = palabraChar.length - 1; i > 0; i--)
        {
            index = random.nextInt(i + 1);
            if (index != i)
            {
                palabraChar[index] ^= palabraChar[i];
                palabraChar[i] ^= palabraChar[index];
                palabraChar[index] ^= palabraChar[i];
            }
        }
        
        String palabraDesordenada = new String(palabraChar);
        return palabraDesordenada;
    }
    
}
