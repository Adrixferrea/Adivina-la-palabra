/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JuegoPalabras;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author luisG
 */
public class HiloServidorTest {
    
    public HiloServidorTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of enviarATodosMensaje method, of class HiloServidor.
     */
    @Test
    public void testEnviarATodosMensaje() {
        System.out.println("enviarATodosMensaje");
        String modo = "";
        String msj = "";
        HiloServidor instance = null;
        instance.enviarATodosMensaje(modo, msj);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of enviarMensaje method, of class HiloServidor.
     */
    @Test
    public void testEnviarMensaje() {
        System.out.println("enviarMensaje");
        String modo = "";
        String msj = "";
        HiloServidor instance = null;
        instance.enviarMensaje(modo, msj);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of enviarATodosListaUsers method, of class HiloServidor.
     */
    @Test
    public void testEnviarATodosListaUsers() {
        System.out.println("enviarATodosListaUsers");
        Mesa mesa = null;
        HiloServidor instance = null;
        instance.enviarATodosListaUsers(mesa);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of enviarListaUsers method, of class HiloServidor.
     */
    @Test
    public void testEnviarListaUsers() {
        System.out.println("enviarListaUsers");
        Mesa mesa = null;
        HiloServidor instance = null;
        instance.enviarListaUsers(mesa);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of enviarATodosNumeroConectados method, of class HiloServidor.
     */
    @Test
    public void testEnviarATodosNumeroConectados() {
        System.out.println("enviarATodosNumeroConectados");
        HiloServidor instance = null;
        instance.enviarATodosNumeroConectados();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of enviarNumeroConectados method, of class HiloServidor.
     */
    @Test
    public void testEnviarNumeroConectados() {
        System.out.println("enviarNumeroConectados");
        HiloServidor instance = null;
        instance.enviarNumeroConectados();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of enviarATodosNuevaRonda method, of class HiloServidor.
     */
    @Test
    public void testEnviarATodosNuevaRonda() {
        System.out.println("enviarATodosNuevaRonda");
        Mesa mesa = null;
        HiloServidor instance = null;
        instance.enviarATodosNuevaRonda(mesa);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of enviarNuevaRonda method, of class HiloServidor.
     */
    @Test
    public void testEnviarNuevaRonda() {
        System.out.println("enviarNuevaRonda");
        Mesa mesa = null;
        HiloServidor instance = null;
        instance.enviarNuevaRonda(mesa);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of finalizarMesaTodos method, of class HiloServidor.
     */
    @Test
    public void testFinalizarMesaTodos() {
        System.out.println("finalizarMesaTodos");
        Mesa mesa = null;
        HiloServidor instance = null;
        instance.finalizarMesaTodos(mesa);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of finalizarMesa method, of class HiloServidor.
     */
    @Test
    public void testFinalizarMesa() {
        System.out.println("finalizarMesa");
        Mesa mesa = null;
        HiloServidor instance = null;
        instance.finalizarMesa(mesa);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of enviarListaGames method, of class HiloServidor.
     */
    @Test
    public void testEnviarListaGames() {
        System.out.println("enviarListaGames");
        Tema tema = null;
        HiloServidor instance = null;
        instance.enviarListaGames(tema);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of enviarErrorMesaPropia method, of class HiloServidor.
     */
    @Test
    public void testEnviarErrorMesaPropia() {
        System.out.println("enviarErrorMesaPropia");
        HiloServidor instance = null;
        instance.enviarErrorMesaPropia();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of enviarErrorPartidaComenzada method, of class HiloServidor.
     */
    @Test
    public void testEnviarErrorPartidaComenzada() {
        System.out.println("enviarErrorPartidaComenzada");
        HiloServidor instance = null;
        instance.enviarErrorPartidaComenzada();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of enviarErrorMesaNoExiste method, of class HiloServidor.
     */
    @Test
    public void testEnviarErrorMesaNoExiste() {
        System.out.println("enviarErrorMesaNoExiste");
        HiloServidor instance = null;
        instance.enviarErrorMesaNoExiste();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of enviarATodosListaRanking method, of class HiloServidor.
     */
    @Test
    public void testEnviarATodosListaRanking() {
        System.out.println("enviarATodosListaRanking");
        HiloServidor instance = null;
        instance.enviarATodosListaRanking();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of enviarListaRanking method, of class HiloServidor.
     */
    @Test
    public void testEnviarListaRanking() {
        System.out.println("enviarListaRanking");
        HiloServidor instance = null;
        instance.enviarListaRanking();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of enviarATodosListaTemas method, of class HiloServidor.
     */
    @Test
    public void testEnviarATodosListaTemas() {
        System.out.println("enviarATodosListaTemas");
        HiloServidor instance = null;
        instance.enviarATodosListaTemas();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of enviarListaTemas method, of class HiloServidor.
     */
    @Test
    public void testEnviarListaTemas() {
        System.out.println("enviarListaTemas");
        HiloServidor instance = null;
        instance.enviarListaTemas();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of buscarJugador method, of class HiloServidor.
     */
    @Test
    public void testBuscarJugador() {
        System.out.println("buscarJugador");
        String nombre = "";
        HiloServidor expResult = null;
        HiloServidor result = HiloServidor.buscarJugador(nombre);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of enviarDataGame method, of class HiloServidor.
     */
    @Test
    public void testEnviarDataGame() {
        System.out.println("enviarDataGame");
        String nombrePartida = "";
        String nombrePlayer1 = "";
        String nombreTema = "";
        HiloServidor instance = null;
        instance.enviarDataGame(nombrePartida, nombrePlayer1, nombreTema);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of run method, of class HiloServidor.
     */
    @Test
    public void testRun() {
        System.out.println("run");
        HiloServidor instance = null;
        instance.run();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
