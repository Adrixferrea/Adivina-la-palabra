/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JuegoPalabras;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author luisG
 */
public class JugadorTest {
    
    public JugadorTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getNombre method, of class Jugador.
     */
    @Test
    public void testGetNombre() {
        System.out.println("getNombre");
        Jugador instance = null;
        String expResult = "";
        String result = instance.getNombre();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getPuntos method, of class Jugador.
     */
    @Test
    public void testGetPuntos() {
        System.out.println("getPuntos");
        Jugador instance = null;
        int expResult = 0;
        int result = instance.getPuntos();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getContrasena method, of class Jugador.
     */
    @Test
    public void testGetContrasena() {
        System.out.println("getContrasena");
        Jugador instance = null;
        String expResult = "";
        String result = instance.getContrasena();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setNombre method, of class Jugador.
     */
    @Test
    public void testSetNombre() {
        System.out.println("setNombre");
        String nombre = "";
        Jugador instance = null;
        instance.setNombre(nombre);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setPuntos method, of class Jugador.
     */
    @Test
    public void testSetPuntos() {
        System.out.println("setPuntos");
        int puntos = 0;
        Jugador instance = null;
        instance.setPuntos(puntos);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of toString method, of class Jugador.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Jugador instance = null;
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of almacenarJugadoresFichero method, of class Jugador.
     */
    @Test
    public void testAlmacenarJugadoresFichero() throws Exception {
        System.out.println("almacenarJugadoresFichero");
        Jugador.almacenarJugadoresFichero();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of buscarJugador method, of class Jugador.
     */
    @Test
    public void testBuscarJugador() {
        System.out.println("buscarJugador");
        String nombre = "";
        Jugador expResult = null;
        Jugador result = Jugador.buscarJugador(nombre);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of vaciarListaJugadores method, of class Jugador.
     */
    @Test
    public void testVaciarListaJugadores() {
        System.out.println("vaciarListaJugadores");
        Jugador.vaciarListaJugadores();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of devolverPrimero method, of class Jugador.
     */
    @Test
    public void testDevolverPrimero() {
        System.out.println("devolverPrimero");
        Jugador expResult = null;
        Jugador result = Jugador.devolverPrimero();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of devolverSegundo method, of class Jugador.
     */
    @Test
    public void testDevolverSegundo() {
        System.out.println("devolverSegundo");
        Jugador expResult = null;
        Jugador result = Jugador.devolverSegundo();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of devolverTercero method, of class Jugador.
     */
    @Test
    public void testDevolverTercero() {
        System.out.println("devolverTercero");
        Jugador expResult = null;
        Jugador result = Jugador.devolverTercero();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
