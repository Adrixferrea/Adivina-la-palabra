/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JuegoPalabras;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author luisG
 */
public class MesaTest {
    
    public MesaTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of addPlayer method, of class Mesa.
     */
    @Test
    public void testAddPlayer() {
        System.out.println("addPlayer");
        HiloServidor jugador = null;
        Mesa instance = null;
        instance.addPlayer(jugador);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getNombre method, of class Mesa.
     */
    @Test
    public void testGetNombre() {
        System.out.println("getNombre");
        Mesa instance = null;
        String expResult = "";
        String result = instance.getNombre();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTema method, of class Mesa.
     */
    @Test
    public void testGetTema() {
        System.out.println("getTema");
        Mesa instance = null;
        Tema expResult = null;
        Tema result = instance.getTema();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getRonda method, of class Mesa.
     */
    @Test
    public void testGetRonda() {
        System.out.println("getRonda");
        Mesa instance = null;
        int expResult = 0;
        int result = instance.getRonda();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setRonda method, of class Mesa.
     */
    @Test
    public void testSetRonda() {
        System.out.println("setRonda");
        int numeroRonda = 0;
        Mesa instance = null;
        instance.setRonda(numeroRonda);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getCreador method, of class Mesa.
     */
    @Test
    public void testGetCreador() {
        System.out.println("getCreador");
        Mesa instance = null;
        HiloServidor expResult = null;
        HiloServidor result = instance.getCreador();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getMesa method, of class Mesa.
     */
    @Test
    public void testGetMesa() {
        System.out.println("getMesa");
        String nombreMesa = "";
        Mesa expResult = null;
        Mesa result = Mesa.getMesa(nombreMesa);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of puntosMesa method, of class Mesa.
     */
    @Test
    public void testPuntosMesa() throws Exception {
        System.out.println("puntosMesa");
        String nombreMesa = "";
        String nombreJugador = "";
        int puntos = 0;
        Mesa.puntosMesa(nombreMesa, nombreJugador, puntos);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
