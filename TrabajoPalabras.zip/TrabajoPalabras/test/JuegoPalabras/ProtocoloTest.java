/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JuegoPalabras;

import javax.swing.DefaultListModel;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author luisG
 */
public class ProtocoloTest {
    
    public ProtocoloTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getArg1 method, of class Protocolo.
     */
    @Test
    public void testGetArg1() {
        System.out.println("getArg1");
        Protocolo instance = null;
        String expResult = "";
        String result = instance.getArg1();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getArg2 method, of class Protocolo.
     */
    @Test
    public void testGetArg2() {
        System.out.println("getArg2");
        Protocolo instance = null;
        String expResult = "";
        String result = instance.getArg2();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getArg3 method, of class Protocolo.
     */
    @Test
    public void testGetArg3() {
        System.out.println("getArg3");
        Protocolo instance = null;
        String expResult = "";
        String result = instance.getArg3();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getLista method, of class Protocolo.
     */
    @Test
    public void testGetLista() {
        System.out.println("getLista");
        Protocolo instance = null;
        DefaultListModel expResult = null;
        DefaultListModel result = instance.getLista();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getAccion method, of class Protocolo.
     */
    @Test
    public void testGetAccion() {
        System.out.println("getAccion");
        Protocolo instance = null;
        String expResult = "";
        String result = instance.getAccion();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
