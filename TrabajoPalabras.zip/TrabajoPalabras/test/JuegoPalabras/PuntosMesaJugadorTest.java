/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JuegoPalabras;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author luisG
 */
public class PuntosMesaJugadorTest {
    
    public PuntosMesaJugadorTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getNombreMesa method, of class PuntosMesaJugador.
     */
    @Test
    public void testGetNombreMesa() {
        System.out.println("getNombreMesa");
        PuntosMesaJugador instance = null;
        String expResult = "";
        String result = instance.getNombreMesa();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getNombreJugador method, of class PuntosMesaJugador.
     */
    @Test
    public void testGetNombreJugador() {
        System.out.println("getNombreJugador");
        PuntosMesaJugador instance = null;
        String expResult = "";
        String result = instance.getNombreJugador();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getPuntos method, of class PuntosMesaJugador.
     */
    @Test
    public void testGetPuntos() {
        System.out.println("getPuntos");
        PuntosMesaJugador instance = null;
        int expResult = 0;
        int result = instance.getPuntos();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setPuntos method, of class PuntosMesaJugador.
     */
    @Test
    public void testSetPuntos() {
        System.out.println("setPuntos");
        int puntos = 0;
        PuntosMesaJugador instance = null;
        instance.setPuntos(puntos);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getPuntosMesaJugador method, of class PuntosMesaJugador.
     */
    @Test
    public void testGetPuntosMesaJugador() {
        System.out.println("getPuntosMesaJugador");
        String nombreMesa = "";
        String nombreJugador = "";
        PuntosMesaJugador expResult = null;
        PuntosMesaJugador result = PuntosMesaJugador.getPuntosMesaJugador(nombreMesa, nombreJugador);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of eliminarPuntosMesa method, of class PuntosMesaJugador.
     */
    @Test
    public void testEliminarPuntosMesa() throws Exception {
        System.out.println("eliminarPuntosMesa");
        String nombreMesa = "";
        PuntosMesaJugador.eliminarPuntosMesa(nombreMesa);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of almacenarPuntosMesaJugadorFichero method, of class PuntosMesaJugador.
     */
    @Test
    public void testAlmacenarPuntosMesaJugadorFichero() throws Exception {
        System.out.println("almacenarPuntosMesaJugadorFichero");
        PuntosMesaJugador.almacenarPuntosMesaJugadorFichero();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of toString method, of class PuntosMesaJugador.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        PuntosMesaJugador instance = null;
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of vaciarListaPuntos method, of class PuntosMesaJugador.
     */
    @Test
    public void testVaciarListaPuntos() {
        System.out.println("vaciarListaPuntos");
        PuntosMesaJugador.vaciarListaPuntos();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
